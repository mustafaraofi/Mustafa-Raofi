<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    public function register(Request $request)
    {
        // First I validate the data. If something is wrong, Laravel returns to the form with errors.
        $data = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|max:255|unique:users,email',
            'password' => 'required|string|min:8|confirmed',
        ]);

        // Here I create a new User object and put the form data inside it.
        $user = new User();
        $user->name = $data['name'];
        $user->email = $data['email'];

        // I do not save the real password. Hash::make() changes it to a secure hash.
        $user->password = Hash::make($data['password']);

        // save() inserts the new user into the users table.
        // Because this project uses MySQL in .env, this data goes to the it_auth_lab database.
        $user->save();

        // After registration I send the user to login and show a success message.
        return redirect()
            ->route('login')
            ->with('success', 'Account created. Please log in.');
    }

    public function login(Request $request)
    {
        // For login I only need a valid email and a password.
        $credentials = $request->validate([
            'email' => 'required|email',
            'password' => 'required|string',
        ]);

        // Auth::attempt() checks the email and compares the password with the saved hash.
        // It reads the user from the users table and Laravel checks the password securely.
        $accepted = Auth::attempt($credentials);

        // If the details are wrong, I return to login and keep only the email field.
        if (! $accepted) {
            return back()->withErrors([
                'email' => 'Email or password is incorrect.',
            ])->onlyInput('email');
        }

        // After successful login I regenerate the session for better security.
        $request->session()->regenerate();

        // The user goes to the page he wanted, or to dashboard if there is no intended page.
        return redirect()->intended(route('dashboard'));
    }

    public function logout(Request $request)
    {
        // This removes the authenticated user from the current session.
        Auth::logout();

        // I invalidate the old session so it cannot be used again.
        $request->session()->invalidate();

        // A new CSRF token is made after logout.
        $request->session()->regenerateToken();

        // Finally I send the user back to login page.
        return redirect()->route('login');
    }
}
