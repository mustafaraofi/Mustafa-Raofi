<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
</head>
<body>
    <h1>Create an account</h1>

    {{-- If validation has errors, I show all of them here for the user. --}}
    @if ($errors->any())
        <ul>
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    @endif

    {{-- This message appears after a successful registration. --}}
    @if (session('success'))
        <p>{{ session('success') }}</p>
    @endif

    {{-- The form uses POST because it is sending new account data to the server. --}}
    <form method="POST" action="{{ route('register.store') }}">
        {{-- @csrf adds a security token to protect the POST request. --}}
        @csrf

        <label for="name">Full name</label>
        {{-- old('name') keeps the typed name if validation fails. --}}
        <input id="name" name="name" type="text" value="{{ old('name') }}" required>

        <br><br>

        <label for="email">Email</label>
        {{-- I also keep the email value so the user does not type it again after an error. --}}
        <input id="email" name="email" type="email" value="{{ old('email') }}" required>

        <br><br>

        <label for="password">Password</label>
        {{-- Password needs at least 8 characters. I do not use old() for passwords. --}}
        <input id="password" name="password" type="password" minlength="8" required>

        <br><br>

        <label for="password_confirmation">Confirm Password</label>
        {{-- Laravel uses this field with the confirmed validation rule. --}}
        <input id="password_confirmation" name="password_confirmation" type="password" minlength="8" required>

        <br><br>

        <button type="submit">Register</button>
    </form>

    <br>
    {{-- This link is for students who already have an account. --}}
    <a href="{{ route('login') }}">Already have an account?</a>
</body>
</html>
