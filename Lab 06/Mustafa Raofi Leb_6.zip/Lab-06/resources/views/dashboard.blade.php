<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>
    <h1>IT Student Portal</h1>

    {{-- auth()->user() gives me the student who is currently logged in. --}}
    <p>Welcome, {{ Anayatullah Mokhles }}.</p>
    <p>Email: {{ anayatullahmokhles@gmail.com }}</p>

    {{-- Logout is a POST form, so I also add @csrf here. --}}
    <form method="POST" action="{{ route('logout') }}">
        @csrf
        <button type="submit">Logout</button>
    </form>
</body>
</html>
