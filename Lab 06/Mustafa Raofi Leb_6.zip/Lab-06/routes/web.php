<?php

use App\Http\Controllers\AuthController;
use Illuminate\Support\Facades\Route;

// When user opens the main page, I send him to the login page.
Route::redirect('/', '/login');

// These routes are for guests. A logged-in user does not need register/login pages.
Route::middleware('guest')->group(function () {
    // This route only shows the registration form.
    Route::view('/register', 'auth.register')->name('register');

    // This route receives the registration form and sends it to register() method.
    Route::post('/register', [AuthController::class, 'register'])
        ->name('register.store');

    // This route shows the login form.
    Route::view('/login', 'auth.login')->name('login');

    // This route receives email and password and sends them to login() method.
    Route::post('/login', [AuthController::class, 'login'])
        ->name('login.store');
});

// The auth middleware protects these routes, so only logged-in users can open them.
Route::middleware('auth')->group(function () {
    // After successful login, the student can see the dashboard page.
    Route::get('/dashboard', function () {
        return view('dashboard');
    })->name('dashboard');

    // Logout is POST because it changes the login session.
    Route::post('/logout', [AuthController::class, 'logout'])
        ->name('logout');
});
