@extends('layouts.app')
@section('title', 'Log in · My Reading List')
@section('content')
<div class="auth-wrap mx-auto">
    <p class="eyebrow">YOUR PERSONAL BOOKSHELF</p>
    <h1 class="fw-bold mb-2">Welcome back.</h1>
    <p class="text-muted mb-4">Log in to continue your reading list.</p>
    <div class="card shadow-sm"><div class="card-body p-4">
        <form method="POST" action="{{ route('login') }}">
            @csrf
            <div class="mb-3">
                <label class="form-label" for="email">Email address</label>
                <input class="form-control @error('email') is-invalid @enderror" id="email" name="email" type="email" value="{{ old('email') }}" required autocomplete="email" autofocus>
                @error('email')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <div class="mb-4">
                <label class="form-label" for="password">Password</label>
                <input class="form-control @error('password') is-invalid @enderror" id="password" name="password" type="password" required autocomplete="current-password">
                @error('password')<div class="invalid-feedback">{{ $message }}</div>@enderror
            </div>
            <button class="btn btn-primary w-100" type="submit">Log in</button>
        </form>
        <p class="small mt-4 mb-0">New here? <a href="{{ route('register') }}">Create an account</a></p>
    </div></div>
</div>
@endsection
