<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>@yield('title', 'My Reading List')</title>
    <link rel="stylesheet" href="{{ asset('css/bootstrap.min.css') }}">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
</head>
<body>
<nav class="navbar navbar-dark bg-dark">
    <div class="container py-2">
        <a class="navbar-brand fw-bold" href="{{ url('/') }}">▤ &nbsp; My Reading List</a>
        @auth
            <div class="d-flex align-items-center gap-3">
                <span class="text-light small">{{ auth()->user()->name }}</span>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button class="btn btn-outline-light btn-sm" type="submit">Log out</button>
                </form>
            </div>
        @endauth
    </div>
</nav>
<main class="container py-5">
    @if(session('success'))
        <div class="alert alert-success" role="status">{{ session('success') }}</div>
    @endif
    @yield('content')
</main>
<footer class="container text-muted small pb-4">BOOK REGISTRATION LAB · Laravel &amp; MySQL</footer>
</body>
</html>
