@extends('layouts.app')
@section('content')
<header class="d-flex flex-wrap justify-content-between align-items-end gap-3 mb-4">
    <div><p class="eyebrow">MY PERSONAL LIBRARY</p><h1 class="fw-bold mb-2">One book at a time.</h1>
    <p class="text-muted mb-0">Keep the books you want to remember, all in one place.</p></div>
    <span class="badge rounded-pill text-bg-light border px-3 py-2">{{ $books->count() }} {{ $books->count() === 1 ? 'book' : 'books' }} registered</span>
</header>
<div class="row g-4">
    <section class="col-lg-4" aria-labelledby="add-heading">
        <div class="card shadow-sm"><div class="card-body p-4">
            <h2 class="h4 mb-1" id="add-heading">Register a book</h2>
            <p class="text-muted small mb-4">Add the details to grow your collection.</p>
            <form method="POST" action="{{ route('books.store') }}">
                {{-- CSRF makes sure this request comes from our form. --}}
                @csrf
                <div class="mb-3">
                    <label class="form-label" for="title">Title</label>
                    <input class="form-control @error('title') is-invalid @enderror" id="title" name="title" value="{{ old('title') }}" maxlength="150" placeholder="e.g. Learning PHP" required>
                    @error('title')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
                <div class="mb-3">
                    <label class="form-label" for="author">Author</label>
                    <input class="form-control @error('author') is-invalid @enderror" id="author" name="author" value="{{ old('author') }}" maxlength="100" placeholder="e.g. Sara Ahmad" required>
                    @error('author')<div class="invalid-feedback">{{ $message }}</div>@enderror
                </div>
                <div class="mb-4">
                    <label class="form-label" for="pages">Pages</label>
                    <input class="form-control @error('pages') is-invalid @enderror" id="pages" name="pages" type="number" value="{{ old('pages') }}" min="1" max="10000" step="1" placeholder="e.g. 120" required>
                    @error('pages')<div class="invalid-feedback">{{ $message }}</div>@enderror
                    <div class="form-text">Between 1 and 10,000 pages.</div>
                </div>
                <button class="btn btn-primary w-100" type="submit">+ Register book</button>
            </form>
        </div></div>
    </section>
    <section class="col-lg-8" aria-labelledby="books-heading">
        <div class="card shadow-sm overflow-hidden">
            <div class="card-body p-4 border-bottom"><h2 class="h4 mb-1" id="books-heading">My Books</h2>
            <p class="text-muted small mb-0">Your latest additions appear first.</p></div>
            @if($books->isEmpty())
                <div class="p-5 text-center"><div class="empty-icon mb-3">▤</div>
                <h3 class="h5">Your shelf is waiting.</h3><p class="text-muted mb-0">No books registered yet. Add your first book using the form.</p></div>
            @else
                <div class="table-responsive"><table class="table align-middle mb-0">
                    <thead class="table-light"><tr><th scope="col">No.</th><th scope="col">Title</th><th scope="col">Author</th><th scope="col" class="text-end">Pages</th></tr></thead>
                    <tbody>@foreach($books as $book)
                        <tr><td class="text-muted">{{ $loop->iteration }}</td><td class="fw-semibold book-title">{{ $book->title }}</td><td class="book-author">{{ $book->author }}</td><td class="text-end">{{ number_format($book->pages) }}</td></tr>
                    @endforeach</tbody>
                </table></div>
            @endif
        </div>
    </section>
</div>
@endsection
