<?php
namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;

class BookController extends Controller
{
    public function index(Request $request)
    {
        // I filter by the session user, so another account cannot see these books.
        $books = Book::where('user_id', $request->user()->id)
            ->latest()->orderByDesc('id')->get();
        return response()->view('dashboard', compact('books'))
            ->header('Cache-Control', 'no-store, private');
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => ['required', 'string', 'max:150'],
            'author' => ['required', 'string', 'max:100'],
            'pages' => ['required', 'integer', 'between:1,10000'],
        ]);
        // I get the owner from login, never from a field submitted by the browser.
        $validated['user_id'] = $request->user()->id;
        Book::create($validated);
        return redirect()->route('dashboard')->with('success', 'Book registered successfully.');
    }
}
