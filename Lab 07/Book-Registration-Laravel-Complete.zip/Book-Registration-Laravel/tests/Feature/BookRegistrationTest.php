<?php
namespace Tests\Feature;

use App\Models\Book;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Tests\TestCase;

class BookRegistrationTest extends TestCase
{
    use RefreshDatabase;

    public function test_guests_cannot_access_dashboard_or_store_books(): void
    {
        $this->get('/dashboard')->assertRedirect('/login');
        $this->post('/books', ['title' => 'X', 'author' => 'Y', 'pages' => 1])->assertRedirect('/login');
        $this->assertDatabaseCount('books', 0);
    }

    public function test_registration_persists_user_and_hashes_password(): void
    {
        $this->post('/register', ['name' => 'Student', 'email' => 'student@example.test',
            'password' => 'StudentPass123!', 'password_confirmation' => 'StudentPass123!'])
            ->assertRedirect('/dashboard');
        $user = User::where('email', 'student@example.test')->firstOrFail();
        $this->assertTrue(Hash::check('StudentPass123!', $user->password));
        $this->assertAuthenticatedAs($user);
        $this->get('/dashboard')->assertSee('No books registered yet.');
    }

    public function test_duplicate_registration_is_rejected(): void
    {
        User::factory()->create(['email' => 'same@example.test']);
        $this->post('/register', ['name' => 'Student', 'email' => 'same@example.test',
            'password' => 'StudentPass123!', 'password_confirmation' => 'StudentPass123!'])
            ->assertSessionHasErrors('email');
        $this->assertDatabaseCount('users', 1);
    }

    public function test_login_and_logout_and_protected_access(): void
    {
        $user = User::factory()->create(['password' => Hash::make('StudentPass123!')]);
        $this->post('/login', ['email' => $user->email, 'password' => 'wrong'])
            ->assertSessionHasErrors('email');
        $this->assertGuest();
        $this->post('/login', ['email' => $user->email, 'password' => 'StudentPass123!'])
            ->assertRedirect('/dashboard');
        $this->assertAuthenticatedAs($user);
        $this->post('/logout')->assertRedirect('/login');
        $this->assertGuest();
        $this->get('/dashboard')->assertRedirect('/login');
    }

    public function test_books_persist_and_show_newest_first_and_ignore_forged_owner(): void
    {
        $owner = User::factory()->create();
        $other = User::factory()->create();
        $this->actingAs($owner)->post('/books', ['title' => 'Learning PHP', 'author' => 'Sara Ahmad',
            'pages' => 120, 'user_id' => $other->id])->assertRedirect('/dashboard')->assertSessionHas('success');
        $this->post('/books', ['title' => 'Laravel Basics', 'author' => 'Ali Hassan', 'pages' => 180])
            ->assertRedirect('/dashboard');
        $this->assertDatabaseHas('books', ['title' => 'Learning PHP', 'user_id' => $owner->id, 'pages' => 120]);
        $this->assertDatabaseCount('books', 2);
        $this->get('/dashboard')->assertSeeInOrder(['Laravel Basics', 'Learning PHP']);
        $this->get('/dashboard')->assertSee('Learning PHP')->assertSee('Laravel Basics');
        $this->actingAs($other)->get('/dashboard')->assertDontSeeText('Learning PHP')->assertDontSeeText('Laravel Basics');
    }

    public function test_invalid_books_are_rejected_and_old_input_is_restored(): void
    {
        $this->actingAs(User::factory()->create());
        $cases = [
            ['title' => '', 'author' => 'Sara', 'pages' => 120],
            ['title' => str_repeat('x', 151), 'author' => 'Sara', 'pages' => 120],
            ['title' => 'Book', 'author' => '', 'pages' => 120],
            ['title' => 'Book', 'author' => str_repeat('x', 101), 'pages' => 120],
            ['title' => 'Book', 'author' => 'Sara', 'pages' => 0],
            ['title' => 'Book', 'author' => 'Sara', 'pages' => 10001],
            ['title' => 'Book', 'author' => 'Sara', 'pages' => 1.5],
            ['title' => 'Book', 'author' => 'Sara', 'pages' => 'abc'],
        ];
        foreach ($cases as $case) {
            $this->from('/dashboard')->post('/books', $case)->assertRedirect('/dashboard')->assertSessionHasErrors();
        }
        $this->assertDatabaseCount('books', 0);
        $this->get('/dashboard')->assertSee('value="Book"', false)->assertSee('invalid-feedback', false);
    }

    public function test_valid_boundaries_are_accepted_and_html_is_escaped(): void
    {
        $this->actingAs(User::factory()->create());
        foreach ([1, 10000] as $pages) {
            $this->post('/books', ['title' => str_repeat('x', 150), 'author' => str_repeat('y', 100), 'pages' => $pages])
                ->assertSessionHasNoErrors();
        }
        $this->post('/books', ['title' => '<script>alert(1)</script>', 'author' => 'Author', 'pages' => 1]);
        $this->get('/dashboard')->assertDontSee('<script>alert(1)</script>', false)
            ->assertSee('&lt;script&gt;alert(1)&lt;/script&gt;', false);
        $this->assertDatabaseCount('books', 3);
    }
}
