# Book Registration & Viewing

A complete Laravel 12 lab application with MySQL persistence, session authentication and a locally bundled Bootstrap 5 stylesheet. PHP 8.2+ is required. Dependencies are bundled in vendor; Composer 2 is needed only to reinstall them. No Node/npm build is needed.

**Windows instructions (Dari/Persian): [README-FA.md](README-FA.md).**

## Quick start

Start XAMPP MySQL, extract the archive and run `setup.bat`, then `start.bat`. Open http://127.0.0.1:8000 and create your account. Setup uses the local defaults in `.env.example`; edit `.env` before setup if your database credentials differ. Setup skips Composer when the bundled vendor folder is present; a dependency reinstall requires internet. No existing data is deleted.

Manual setup: copy `.env.example` to `.env`, run `composer install`, `php artisan key:generate`, `php scripts/create-database.php`, `php artisan migrate`, and `php artisan serve`.

## Scope

- Registration, login, POST logout, hashed passwords, session regeneration, CSRF protection and login rate limiting.
- Book title (required, max 150), author (required, max 100), pages (integer 1–10,000).
- Authenticated GET `/dashboard` and POST `/books`.
- User ID is assigned from the authenticated session, never trusted from submitted input.
- Own books only, newest first; field validation errors, old input, success and empty states.
- MySQL foreign key from books to users; database migrations included.
- Simple explanatory comments in important PHP and Blade files.

Run `php artisan test` for the included feature suite. Tests use in-memory SQLite, not the application's MySQL database. This project is standalone and does not overwrite an existing authentication project.

## Dependencies and sources

Laravel skeleton: https://github.com/laravel/laravel/tree/12.x (MIT; see LICENSE).
Laravel installation documentation: https://laravel.com/docs/12.x/installation.
Bootstrap 5.3.3: https://getbootstrap.com/ (MIT; copyright notice retained in public/css/bootstrap.min.css).

Use only for local lab development with the default configuration. PHP dependencies are declared in composer.json and fixed by composer.lock when supplied; third-party packages are installed through Composer.
