<?php
// Run only during local setup. This does not delete or replace existing data.
require dirname(__DIR__).'/vendor/autoload.php';
Dotenv\Dotenv::createImmutable(dirname(__DIR__))->load();
$name = $_ENV['DB_DATABASE'] ?? 'book_registration';
if (!preg_match('/^[a-zA-Z0-9_]+$/', $name)) {
    fwrite(STDERR, "Use only letters, numbers and underscores in DB_DATABASE.\n");
    exit(1);
}
try {
    $host = $_ENV['DB_HOST'] ?? '127.0.0.1';
    $port = $_ENV['DB_PORT'] ?? '3306';
    $pdo = new PDO("mysql:host=$host;port=$port;charset=utf8mb4", $_ENV['DB_USERNAME'] ?? 'root', $_ENV['DB_PASSWORD'] ?? '', [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$name` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    echo "Database ready: $name\n";
} catch (PDOException $e) {
    fwrite(STDERR, "Database setup failed. Start XAMPP MySQL and check the DB settings in .env.\n".$e->getMessage()."\n");
    exit(1);
}
