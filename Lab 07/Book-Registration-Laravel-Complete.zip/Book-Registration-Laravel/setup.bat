@echo off
setlocal
cd /d "%~dp0"
if exist "C:\xampp\php\php.exe" set "PATH=C:\xampp\php;%PATH%"
where php >nul 2>nul
if errorlevel 1 goto no_php
if not exist .env copy .env.example .env >nul
if exist vendor\autoload.php goto dependencies_ready
where composer >nul 2>nul
if errorlevel 1 goto no_composer
call composer install --prefer-dist --no-interaction
if errorlevel 1 goto failed
:dependencies_ready
php artisan config:clear
if errorlevel 1 goto failed
findstr /R /C:"^APP_KEY=base64:" .env >nul
if errorlevel 1 php artisan key:generate
if errorlevel 1 goto failed
php scripts/create-database.php
if errorlevel 1 goto failed
php artisan migrate --force
if errorlevel 1 goto failed
echo Setup complete. Run start.bat and open http://127.0.0.1:8000
pause
exit /b 0
:no_php
echo PHP not found. Install XAMPP with PHP 8.2 or newer.
goto failed
:no_composer
echo Composer not found. Install Composer and select C:\xampp\php\php.exe.
:failed
echo Setup did not finish. Read the error above and README-FA.md.
pause
exit /b 1
