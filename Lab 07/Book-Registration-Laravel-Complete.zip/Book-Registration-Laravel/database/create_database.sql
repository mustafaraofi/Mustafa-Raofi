-- Optional: import into phpMyAdmin if creating the database manually.
-- Laravel migrations create all tables; do not manually create them a second time.
CREATE DATABASE IF NOT EXISTS book_registration CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
