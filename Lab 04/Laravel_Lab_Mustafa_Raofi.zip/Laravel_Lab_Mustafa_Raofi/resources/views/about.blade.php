<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>About Me</title>
</head>
<body>
    <h1>About Me</h1>
    <p>Full Name: Mustafa Raofi</p>
    <p>Student ID: __________________</p>
    <p>I want to learn how to build web applications using Laravel and PHP.</p>
    <p>I also want to understand how routes, Blade views, and backend features work together.</p>

    <a href="{{ url('/') }}">Back to Home</a>
</body>
</html>
